import React from 'react';
import './header.css';

const Header = () => {
  return (
    <div className='header'>
        <h1>DSA Sheets</h1>
        <h3>Way to Crack DSA</h3>
    </div>
  )
}

export default Header